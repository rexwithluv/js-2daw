# Ejercicio

Haz que los datos que se cubran en el formulario, al usar el botón Finalizar, se muestren en una nueva página creada de antemano (y llamada "mostrar_datos.html"), y que sean pasados empleando LocalStorage o SessionStorage.

Que los datos que están contenidos en la variable miarray, se muestren después de mostrar el código.

EL resultado final debe ser algo así: (imagen dada por la profesora)

(No necesario complicarse con formato,
El interés es probar localStorage y/o sessionStorage).

Resultado exercicio

Explica en texto en liña (al realizar al entrega), cuál de los dos métodos Storage se escoge y el motivo de la elección.
